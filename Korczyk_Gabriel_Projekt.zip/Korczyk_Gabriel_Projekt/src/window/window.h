#pragma once
#include "../render/draw.hpp"
#include <raylib.h>
#include "../grid/map.hpp"

class Window {
public:
    void init();
};
