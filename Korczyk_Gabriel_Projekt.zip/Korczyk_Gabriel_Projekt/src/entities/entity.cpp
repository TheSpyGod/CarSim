#include "entity.hpp"

Entity::~Entity() {} //Destructor
